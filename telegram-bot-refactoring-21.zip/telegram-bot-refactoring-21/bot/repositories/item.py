# Файл: bot/repositories/item.py
import logging
import asyncpg
from typing import Optional, List, Dict
from bot.db import get_pool, retry_on_db_error
from bot.utils.validators import extract_serials

logger = logging.getLogger(__name__)

class ItemRepository:
    """Репозиторий для работы с товарами и категориями."""

    @staticmethod
    @retry_on_db_error()
    async def get_or_create_category(name: str, conn=None) -> int:
        """Возвращает ID категории по имени, создаёт при отсутствии."""
        norm_name = name.lower().rstrip(':')
        if conn is None:
            pool = await get_pool()
            async with pool.acquire() as conn:
                return await ItemRepository._get_or_create_category(conn, norm_name, name)
        else:
            return await ItemRepository._get_or_create_category(conn, norm_name, name)

    @staticmethod
    async def _get_or_create_category(conn, norm_name: str, original_name: str) -> int:
        row = await conn.fetchrow('SELECT id FROM categories WHERE LOWER(name) = $1', norm_name)
        if row:
            return row['id']
        # При создании категории устанавливаем sort_order = max(sort_order) + 1
        max_order = await conn.fetchval('SELECT COALESCE(MAX(sort_order), -1) FROM categories')
        try:
            row = await conn.fetchrow(
                'INSERT INTO categories (name, sort_order) VALUES ($1, $2) RETURNING id',
                original_name, max_order + 1
            )
            return row['id']
        except asyncpg.UniqueViolationError:
            row = await conn.fetchrow('SELECT id FROM categories WHERE name = $1', original_name)
            if row:
                return row['id']
            else:
                logger.error(f"Не удалось создать или найти категорию {original_name} после UniqueViolation")
                raise

    @staticmethod
    @retry_on_db_error()
    async def add_item(text: str, serial: Optional[str] = None, category_id: Optional[int] = None, category_name: Optional[str] = None):
        """Добавляет товар. Можно указать category_id или category_name."""
        if category_id is None:
            if category_name is None:
                category_name = "Общее:"
            cat_id = await ItemRepository.get_or_create_category(category_name)
        else:
            cat_id = category_id
        normalized_serial = serial.strip().upper() if serial else None
        is_booked = 'Бронь от' in text
        pool = await get_pool()
        async with pool.acquire() as conn:
            await conn.execute('''
                INSERT INTO items (text, serial, category_id, is_booked)
                VALUES ($1, $2, $3, $4)
            ''', text, normalized_serial, cat_id, is_booked)

    @staticmethod
    @retry_on_db_error()
    async def get_item_id_by_serial(serial: str, conn=None) -> Optional[int]:
        if not serial:
            return None
        normalized = serial.strip().upper()
        if conn is None:
            pool = await get_pool()
            async with pool.acquire() as conn:
                row = await conn.fetchrow('SELECT id FROM items WHERE UPPER(serial) = $1', normalized)
                return row['id'] if row else None
        else:
            row = await conn.fetchrow('SELECT id FROM items WHERE UPPER(serial) = $1', normalized)
            return row['id'] if row else None

    @staticmethod
    @retry_on_db_error()
    async def get_item_by_serial(serial: str, conn=None) -> Optional[Dict]:
        normalized = serial.strip().upper()
        if conn is None:
            pool = await get_pool()
            async with pool.acquire() as conn:
                row = await conn.fetchrow('''
                    SELECT i.id, i.text, c.id as category_id, c.name as category_name
                    FROM items i
                    JOIN categories c ON i.category_id = c.id
                    WHERE UPPER(i.serial) = $1
                ''', normalized)
                return dict(row) if row else None
        else:
            row = await conn.fetchrow('''
                SELECT i.id, i.text, c.id as category_id, c.name as category_name
                FROM items i
                JOIN categories c ON i.category_id = c.id
                WHERE UPPER(i.serial) = $1
            ''', normalized)
            return dict(row) if row else None

    @staticmethod
    @retry_on_db_error()
    async def get_item_by_text(text: str, conn=None) -> Optional[Dict]:
        """Ищет товар по точному тексту, возвращает id, текст и имя категории."""
        if conn is None:
            pool = await get_pool()
            async with pool.acquire() as conn:
                row = await conn.fetchrow('''
                    SELECT i.id, i.text, c.name as category_name
                    FROM items i
                    JOIN categories c ON i.category_id = c.id
                    WHERE i.text = $1
                ''', text)
                return dict(row) if row else None
        else:
            row = await conn.fetchrow('''
                SELECT i.id, i.text, c.name as category_name
                FROM items i
                JOIN categories c ON i.category_id = c.id
                WHERE i.text = $1
            ''', text)
            return dict(row) if row else None

    @staticmethod
    @retry_on_db_error()
    async def remove_item_by_serial(serial: str, conn=None) -> int:
        normalized = serial.strip().upper() if serial else None
        if conn is None:
            pool = await get_pool()
            async with pool.acquire() as conn:
                result = await conn.execute('DELETE FROM items WHERE UPPER(serial) = $1', normalized)
                return int(result.split()[1]) if result.startswith('DELETE') else 0
        else:
            result = await conn.execute('DELETE FROM items WHERE UPPER(serial) = $1', normalized)
            return int(result.split()[1]) if result.startswith('DELETE') else 0

    @staticmethod
    @retry_on_db_error()
    async def add_deleted_item(item_id: int, text: str, serial: str, category_id: int, reason: str = 'manual', conn=None):
        if conn is None:
            pool = await get_pool()
            async with pool.acquire() as conn:
                await conn.execute('''
                    INSERT INTO deleted_items (item_id, text, serial, category_id, reason)
                    VALUES ($1, $2, $3, $4, $5)
                ''', item_id, text, serial, category_id, reason)
        else:
            await conn.execute('''
                INSERT INTO deleted_items (item_id, text, serial, category_id, reason)
                VALUES ($1, $2, $3, $4, $5)
            ''', item_id, text, serial, category_id, reason)

    @staticmethod
    @retry_on_db_error()
    async def get_last_deleted_item() -> Optional[Dict]:
        pool = await get_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow('''
                SELECT * FROM deleted_items
                WHERE restored = FALSE
                ORDER BY deleted_at DESC
                LIMIT 1
            ''')
            return dict(row) if row else None

    @staticmethod
    @retry_on_db_error()
    async def restore_deleted_item(deleted_id: int) -> bool:
        pool = await get_pool()
        async with pool.acquire() as conn:
            result = await conn.execute('UPDATE deleted_items SET restored = TRUE WHERE id = $1', deleted_id)
            return result == "UPDATE 1"

    @staticmethod
    @retry_on_db_error()
    async def mark_item_booked(item_id: int, book_text: str, conn=None):
        if conn is None:
            pool = await get_pool()
            async with pool.acquire() as conn:
                await conn.execute('''
                    UPDATE items SET text = $1, is_booked = TRUE WHERE id = $2
                ''', book_text, item_id)
        else:
            await conn.execute('''
                UPDATE items SET text = $1, is_booked = TRUE WHERE id = $2
            ''', book_text, item_id)

    @staticmethod
    @retry_on_db_error()
    async def get_all_categories_with_items():
        """Возвращает категории с товарами, отсортированные по sort_order, затем по имени, исключая служебную __SYSTEM__."""
        pool = await get_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch('''
                SELECT c.name as category_name, i.text as item_text
                FROM categories c
                LEFT JOIN items i ON c.id = i.category_id
                WHERE c.name != '__SYSTEM__'
                ORDER BY c.sort_order, c.name, i.id
            ''')
            categories = {}
            for row in rows:
                cat = row['category_name']
                if cat not in categories:
                    categories[cat] = []
                if row['item_text']:
                    categories[cat].append(row['item_text'])
            return [{"header": cat, "items": items} for cat, items in categories.items()]

    @staticmethod
    @retry_on_db_error()
    async def get_all_items_serials():
        pool = await get_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch('SELECT text, serial FROM items')
            return [dict(row) for row in rows]

    @staticmethod
    @retry_on_db_error()
    async def bulk_replace_assortment(categories: List[Dict[str, List[str]]]) -> None:
        from bot.services.assortment import AssortmentService
        pool = await get_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                await conn.execute('TRUNCATE TABLE categories CASCADE')
                category_names = [cat['header'] for cat in categories]
                if category_names:
                    # Вставляем категории с sort_order по порядку следования в списке
                    for idx, name in enumerate(category_names):
                        await conn.execute(
                            'INSERT INTO categories (name, sort_order) VALUES ($1, $2)',
                            name, idx
                        )

                rows = await conn.fetch('SELECT id, name FROM categories')
                cat_id_map = {row['name']: row['id'] for row in rows}

                items_data = []
                for cat in categories:
                    cat_id = cat_id_map[cat['header']]
                    for item_text in cat['items']:
                        serials = extract_serials(item_text)
                        serial = serials[0].strip().upper() if serials else None
                        is_booked = 'Бронь от' in item_text
                        items_data.append((item_text, serial, cat_id, is_booked))

                if items_data:
                    values_placeholder = []
                    params = []
                    idx = 1
                    for text, serial, cat_id, is_booked in items_data:
                        values_placeholder.append(f"(${idx}, ${idx+1}, ${idx+2}, ${idx+3})")
                        params.extend([text, serial, cat_id, is_booked])
                        idx += 4
                    query = f'INSERT INTO items (text, serial, category_id, is_booked) VALUES {", ".join(values_placeholder)}'
                    await conn.execute(query, *params)

        await AssortmentService.invalidate_cache()
