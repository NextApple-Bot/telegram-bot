# Файл: bot/handlers/callbacks.py
import json
import csv
import tempfile
import os
import logging
from datetime import datetime

from aiogram import F, Router
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, FSInputFile
from aiogram.exceptions import TelegramBadRequest
from cachetools import TTLCache

from bot import config
from bot.services.assortment import AssortmentService
from bot.repositories import StatsRepository, ClientRepository, ItemRepository
from bot.db import get_pool
from bot.utils.sort import get_full_model_name, detect_sim_type
from bot.utils.markdown import escape_markdown_v1
from .base import show_inventory, show_help, cancel_action, get_main_menu_keyboard
from .topics.common import export_assortment_to_topic
from bot.utils.helpers import send_and_clean

router = Router()
logger = logging.getLogger(__name__)  # Собственный логгер, а не из base

last_stats_message = TTLCache(maxsize=1000, ttl=3600)
last_inventory_message = TTLCache(maxsize=1000, ttl=3600)
last_remains_message = TTLCache(maxsize=1000, ttl=3600)
last_clients_month_message = TTLCache(maxsize=1000, ttl=3600)


async def safe_delete(message):
    try:
        await message.delete()
    except Exception as e:
        logger.warning(f"Не удалось удалить сообщение: {e}")


@router.callback_query(F.data == "menu:inventory")
async def process_inventory(callback: CallbackQuery):
    try:
        await callback.answer("⏳ Загружаю ассортимент...")
    except Exception as e:
        logger.warning(f"Не удалось ответить на callback: {e}")
    chat_id = callback.message.chat.id
    if chat_id in last_inventory_message:
        try:
            await callback.bot.delete_message(chat_id, last_inventory_message[chat_id])
        except Exception:
            pass
    msg = await show_inventory(callback.bot, chat_id)
    if msg:
        last_inventory_message[chat_id] = msg.message_id
        await safe_delete(callback.message)
        keyboard = get_main_menu_keyboard()
        await send_and_clean(
            bot=callback.bot, chat_id=chat_id,
            text="Выберите действие:",
            reply_markup=keyboard,
            message_thread_id=callback.message.message_thread_id,
            delete_after=60
        )


@router.callback_query(F.data == "menu:stats")
async def process_stats(callback: CallbackQuery):
    try:
        await callback.answer("⏳ Загружаю статистику...")
    except Exception as e:
        logger.warning(f"Не удалось ответить на callback: {e}")
    chat_id = callback.message.chat.id
    if chat_id in last_stats_message:
        try:
            await callback.bot.delete_message(chat_id, last_stats_message[chat_id])
        except Exception:
            pass
    stats = await StatsRepository.get_today_stats()
    stats_text = (
        f"📊 Статистика на {stats['date']}\n\n"
        f"Продажи: {stats['sales_count']}\n"
        f"Предзаказы: {stats['preorders_count']}\n"
        f"Брони: {stats['bookings_count']}\n\n"
        f"💰 Суммы продаж:\n"
        f"Наличные: {stats['sales']['cash']:.0f} ₽\n"
        f"Терминал: {stats['sales']['terminal']:.0f} ₽\n"
        f"QR-код: {stats['sales']['qr']:.0f} ₽\n"
        f"Перевод: {stats['sales']['transfer']:.0f} ₽\n"
        f"По счёту: {stats['sales']['invoice']:.0f} ₽\n"
        f"Рассрочка: {stats['sales']['installment']:.0f} ₽\n\n"
        f"💸 Предзаказы:\n"
        f"Наличные: {stats['preorders']['cash']:.0f} ₽\n"
        f"Терминал: {stats['preorders']['terminal']:.0f} ₽\n"
        f"QR-код: {stats['preorders']['qr']:.0f} ₽\n"
        f"Перевод: {stats['preorders']['transfer']:.0f} ₽\n"
        f"По счёту: {stats['preorders']['invoice']:.0f} ₽\n"
        f"Рассрочка: {stats['preorders']['installment']:.0f} ₽\n\n"
        f"🔖 Брони: {stats['bookings_total']:.0f} ₽"
    )
    await safe_delete(callback.message)
    msg = await send_and_clean(
        bot=callback.bot, chat_id=chat_id,
        text=stats_text,
        message_thread_id=callback.message.message_thread_id,
        delete_after=60
    )
    last_stats_message[chat_id] = msg.message_id
    keyboard = get_main_menu_keyboard()
    await send_and_clean(
        bot=callback.bot, chat_id=chat_id,
        text="Выберите действие:",
        reply_markup=keyboard,
        message_thread_id=callback.message.message_thread_id,
        delete_after=60
    )


@router.callback_query(F.data == "menu:export_assortment")
async def process_export_assortment(callback: CallbackQuery):
    try:
        await callback.answer("⏳ Выгружаю ассортимент...")
    except Exception as e:
        logger.warning(f"Не удалось ответить на callback: {e}")
    await export_assortment_to_topic(callback.bot, callback.from_user.id)
    await send_and_clean(
        bot=callback.bot,
        chat_id=callback.from_user.id,
        text="✅ Ассортимент выгружен в топик.",
        message_thread_id=callback.message.message_thread_id,
        delete_after=60
    )


@router.callback_query(F.data == "menu:clear")
async def process_clear(callback: CallbackQuery):
    """Обработчик кнопки 'Очистить ассортимент' (menu:clear)"""
    try:
        await callback.answer()
    except Exception as e:
        logger.warning(f"Не удалось ответить на callback: {e}")
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⚠️ ДА, УДАЛИТЬ ВСЁ", callback_data="reset_assortment:confirm")],
        [InlineKeyboardButton(text="❌ Отмена", callback_data="menu:cancel")]
    ])
    await send_and_clean(
        bot=callback.bot,
        chat_id=callback.message.chat.id,
        text="⚠️ **ВНИМАНИЕ!** Эта команда **полностью удалит** все товары и категории из ассортимента.\nДанные о клиентах, покупках, статистике и бронях сохранятся.\n\nВы уверены?",
        reply_markup=keyboard,
        parse_mode='Markdown',
        message_thread_id=callback.message.message_thread_id,
        delete_after=60
    )


@router.callback_query(F.data == "menu:remains")
async def process_remains(callback: CallbackQuery):
    try:
        await callback.answer("⏳ Формирую отчёт по остаткам...")
    except Exception as e:
        logger.warning(f"Не удалось ответить на callback: {e}")

    chat_id = callback.message.chat.id
    if chat_id in last_remains_message:
        try:
            await callback.bot.delete_message(chat_id, last_remains_message[chat_id])
        except Exception:
            pass

    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch('''
            SELECT i.text 
            FROM items i
            JOIN categories c ON i.category_id = c.id
            WHERE i.is_booked = false 
              AND c.name NOT IN ('Б/У:', 'Б/У', 'NS:', 'NS')
        ''')

    if not rows:
        await safe_delete(callback.message)
        await send_and_clean(bot=callback.bot, chat_id=chat_id, text="📭 Нет товаров в наличии.", message_thread_id=callback.message.message_thread_id, delete_after=60)
        keyboard = get_main_menu_keyboard()
        await send_and_clean(bot=callback.bot, chat_id=chat_id, text="Выберите действие:", reply_markup=keyboard, message_thread_id=callback.message.message_thread_id, delete_after=60)
        return

    groups = {}
    for row in rows:
        text = row['text']
        full_name = get_full_model_name(text)
        sim = detect_sim_type(text)
        key = (full_name, sim)
        groups[key] = groups.get(key, 0) + 1

    today = datetime.now().strftime("%d.%m.%y")
    with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as tmp:
        writer = csv.writer(tmp)
        writer.writerow(['Модель', 'Тип SIM', 'Количество'])
        for (full_name, sim), count in sorted(groups.items()):
            writer.writerow([full_name, sim if sim != 'other' else '', count])
        tmp_path = tmp.name

    await safe_delete(callback.message)
    sent = await callback.message.answer_document(
        FSInputFile(tmp_path, filename=f"remains_{today}.csv"),
        caption=f"📦 Остатки на {today}"
    )
    last_remains_message[chat_id] = sent.message_id
    os.unlink(tmp_path)

    keyboard = get_main_menu_keyboard()
    await send_and_clean(bot=callback.bot, chat_id=chat_id, text="Выберите действие:", reply_markup=keyboard, message_thread_id=callback.message.message_thread_id, delete_after=60)


@router.callback_query(F.data.startswith("month:"))
async def process_month_selection(callback: CallbackQuery):
    try:
        await callback.answer()
    except Exception:
        pass

    month = callback.data.split(":")[1]
    chat_id = callback.message.chat.id

    if chat_id in last_clients_month_message:
        try:
            await callback.bot.delete_message(chat_id, last_clients_month_message[chat_id])
        except Exception:
            pass

    await callback.message.edit_text(f"⏳ Формирую отчёт за {month}...")

    try:
        rows = await ClientRepository.get_clients_data_for_month(month)
        if not rows:
            await safe_delete(callback.message)
            await send_and_clean(bot=callback.bot, chat_id=chat_id, text="📭 Нет данных за этот месяц.", message_thread_id=callback.message.message_thread_id, delete_after=60)
            keyboard = get_main_menu_keyboard()
            await send_and_clean(bot=callback.bot, chat_id=chat_id, text="Выберите действие:", reply_markup=keyboard, message_thread_id=callback.message.message_thread_id, delete_after=60)
            return

        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, encoding='utf-8') as tmp:
            writer = csv.writer(tmp)
            writer.writerow([
                'ID клиента', 'ФИО', 'Телефон', 'Все телефоны', 'Telegram', 'Соцсети', 'Источник',
                'Дата регистрации клиента', 'ID покупки', 'Дата покупки', 'Товары', 'Сумма',
                'Способ оплаты (JSON)', 'Тип покупки'
            ])
            for row in rows:
                items_text = ''
                if row['items_json']:
                    try:
                        items = json.loads(row['items_json'])
                        items_text = '; '.join([f"{it.get('item_text', '')[:50]} ({it.get('price', '')}₽)" for it in items])
                    except Exception:
                        items_text = row['items_json']
                client_created = row['client_created_at'].strftime("%d.%m.%y") if row['client_created_at'] else ''
                purchase_created = row['purchase_created_at'].strftime("%d.%m.%y") if row['purchase_created_at'] else ''
                writer.writerow([
                    row['client_id'], row['full_name'], row['phone'], row['phones'],
                    row['telegram_username'], row['social_network'], row['referral_source'],
                    client_created, row['purchase_id'], purchase_created,
                    items_text, row['total_amount'], row['payment_details'], row['purchase_type']
                ])
            tmp_path = tmp.name

        await safe_delete(callback.message)
        sent = await callback.message.answer_document(
            FSInputFile(tmp_path, filename=f"clients_{month}.csv"),
            caption=f"📁 Данные клиентов за {month}"
        )
        last_clients_month_message[chat_id] = sent.message_id
        os.unlink(tmp_path)

        keyboard = get_main_menu_keyboard()
        await send_and_clean(bot=callback.bot, chat_id=chat_id, text="Выберите действие:", reply_markup=keyboard, message_thread_id=callback.message.message_thread_id, delete_after=60)

    except Exception as e:
        logger.exception(f"Ошибка при формировании отчёта за {month}")
        await safe_delete(callback.message)
        await send_and_clean(bot=callback.bot, chat_id=chat_id, text="❌ Произошла ошибка при формировании отчёта.", message_thread_id=callback.message.message_thread_id, delete_after=60)
        keyboard = get_main_menu_keyboard()
        await send_and_clean(bot=callback.bot, chat_id=chat_id, text="Выберите действие:", reply_markup=keyboard, message_thread_id=callback.message.message_thread_id, delete_after=60)


# Обработчики для кнопок очистки, удаления и т.д. — они остаются без изменений, просто теперь они в основном коде
# (убедись, что они импортированы и активны в исходном файле)
