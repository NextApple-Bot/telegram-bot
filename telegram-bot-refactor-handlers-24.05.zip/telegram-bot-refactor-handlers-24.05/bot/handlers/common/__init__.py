from .router import router as common_router

__all__ = ["common_router"]
